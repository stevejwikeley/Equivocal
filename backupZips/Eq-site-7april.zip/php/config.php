<?php
// Write contact email reciever here
$contactEmail = "webnus.net@gmail.com";  
// Write Subscribe email reciever here
$subscribeEmail = "webnus.net@gmail.com";

?>