Equivocal
=========

Equivocal
